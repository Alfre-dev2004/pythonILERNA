#Alfredo Noriega Aranda

result1 = 15%4
result2 = 3**4
result3 = 10//3

print("result1 ",result1)
print("result2 ",result2)
print("result3 ",result3)

expresion_and = (2>1 and 30<20)  #true and false entonces el resultado es false
expresion_or = (1<0 or 30==30 ) #false or true entonces el resultado es true
expresion_not = not(20==20) #es true pero por el not cambia a false

print("***************************")
print("2>1 and 10<20 = ",expresion_and)
print("1<0 or 30==30 = ",expresion_or)
print("not(20==20) = ",expresion_not)
