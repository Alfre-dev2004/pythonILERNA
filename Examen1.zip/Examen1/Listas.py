#Alfredo Noriega
Lista = [1,2,3,4,5] #Creo la lista

print("Lista inicial: ",Lista)

Lista.append(6) #Agrego el numero 6

print("Agregamos el 6: ",Lista)

Lista.pop() #Elimino el ultimo de la lista

print("Eliminamos el ultimo de la lista: ",Lista)