#Alfredo Noriega Aranda

tupla = ("azul","rojo","verde","naranja","amarillo")
print("Tupla completa: ", tupla)

print("El primer elemento es ",tupla[0], " y el ultimo es ",tupla[-1]) #llamo a la tupa en posicion 0 y a la ultima con el -1

print("El numero de elementos es: ",len(tupla)) #saco el longitud de la tupla

set = {1,2,3,4,3,5,5}

print("El set completo es: ", set) #No muestra los repetidos porque un set no permite duplicados

set.add(6)#Agrego el 6

print("Agregamos el 6: ",set)

set.remove(5) #Elimino el 5

print("Agregamos el 5: ",set)