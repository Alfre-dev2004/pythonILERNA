#Alfredo Noriega Aranda

string = "Hola"
entero = 1
booleano = True
nombre = input("Dame un nombre: ")

print(string)

print(entero)

print(booleano)

print("Hola " + nombre)